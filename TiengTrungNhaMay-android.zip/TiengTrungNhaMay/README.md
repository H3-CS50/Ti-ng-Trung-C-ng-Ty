# Tiếng Trung Nhà Máy (Android)

Build APK không cần máy tính, làm trên điện thoại:
1. Tạo repo mới trên github.com → Add file → Upload files → tải lên toàn bộ nội dung thư mục này (giữ nguyên cấu trúc, gồm cả .github).
2. Vào tab Actions → "Build APK" → chờ ~5 phút đến khi có dấu tích xanh.
3. Mở lần chạy đó → mục Artifacts → tải `TiengTrungNhaMay-apk` (file zip) → giải nén lấy `app-debug.apk` → cài.

Giọng đọc: app dùng Google Text-to-Speech của máy. Nếu không nghe tiếng, tải giọng Tiếng Trung trong Cài đặt → Chuyển văn bản thành giọng nói.
Sửa nội dung bài học: chỉnh `app/src/main/assets/index.html` rồi push lại, Actions sẽ tự build APK mới.
